#!/bin/bash
#Please set INSTALLDIR and SOURCEDIR at OpenCV_cmake.sh
INSTALLDIR=~/Documents/opencv/opencv_m5threads

unzip opencv-2.4.10_m5threads.zip
unzip m5threads.zip
#--m5threads--
cd m5threads/
make
cd ..
#--opencv--
mkdir opencv_build
cp OpenCV_cmake.sh opencv_build
cd opencv_build
./OpenCV_cmake.sh
make
make install
cd ..
#--replace pthreads--
sed -i 's/-lpthread/\ /g' $(INSTALLDIR)/lib/pkgconfig/opencv.pc
